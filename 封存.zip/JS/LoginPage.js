let page = document.getElementsByClassName('login-page')[0];
let iconYonghu = document.querySelector('.icon-yonghu');

function disableScroll() {
    document.body.style.overflow = 'hidden';
}

// JavaScript函数以启用滚动
function enableScroll() {
    document.body.style.overflow = '';
}

function OpenLoginPage(event) {
    // 获取点击事件的目标元素
    var target = event.target;

    // 检查点击事件的目标元素是否是 .icon-yonghu 元素本身
    if (target === iconYonghu) {
        page.style.display = "flex";
        disableScroll();
    }
}

// 在整个文档上添加点击事件监听器
document.addEventListener('click', function(event){
    OpenLoginPage(event);
});

function ExitLoginPage(){
    page.style.display="none";
    enableScroll();
}

let tick1 = document.getElementsByClassName('tick')[0];
let tick2 = document.getElementsByClassName('tick')[1];
function change1() {
    // 获取 tick1 元素的计算后的样式
    var computedStyle = window.getComputedStyle(tick1);

    // 获取计算后的背景颜色
    var backgroundColor = computedStyle.backgroundColor;

    if (backgroundColor === "rgb(170, 170, 170)") {
        tick1.style.backgroundColor = "rgb(48, 129, 235)";
    } else {
        tick1.style.backgroundColor = "rgb(170, 170, 170)";
    }
}


function change2() {
    var computedStyle = window.getComputedStyle(tick2);
    var backgroundColor = computedStyle.backgroundColor;

    if (backgroundColor === "rgb(170, 170, 170)") {
        tick2.style.backgroundColor = "rgb(48, 129, 235)";
    } else {
        tick2.style.backgroundColor = "rgb(170, 170, 170)";
    }
}

//接口部分

//登录
// document.getElementsByClassName("qqlogin-btn").addEventListener("click", function(event) {
//     event.preventDefault(); // 阻止表单提交默认行为

//     // 获取用户名和密码
//     var username = encodeURIComponent(document.getElementById("username").value);
//     var password = encodeURIComponent(document.getElementById("password").value);

//     // 创建 XMLHttpRequest 对象
//     var xhr = new XMLHttpRequest();
//     xhr.withCredentials = true;

//     // 监听 XMLHttpRequest 状态变化
//     xhr.addEventListener("readystatechange", function() {
//       if (this.readyState === 4) {
//         // 请求完成时
//         if (this.status === 200) {
//           // 如果响应状态码为 200，表示登录成功
//           document.getElementById("loginMessage").style.display = "block"; // 显示登录成功提示
//         } else {
//           // 否则登录失败，可以在这里处理其他逻辑，比如显示错误信息
//           alert("Login failed. Please check your username and password.");
//         }
//       }
//     });

//     // 发送登录请求
//     xhr.open("GET", "http://43.163.205.89:8080/user/login?username=" + username + "&password=" + password);
//     xhr.setRequestHeader("token", "");
//     xhr.setRequestHeader("User-Agent", "Apifox/1.0.0 (https://apifox.com)");
//     xhr.send();
//   });